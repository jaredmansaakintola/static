https://github.com/jaredosei/static
